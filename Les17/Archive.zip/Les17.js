const getRefundBtn = document.getElementById('getRefund');
getRefundBtn.onclick = createListRef;

async function createListRef() {
    const datas = await getRefund();
    console.log(datas);
}


async function getRefund() {
    const resp = await fetch('https://oijv97k0l6.execute-api.eu-central-1.amazonaws.com/test/refunds', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    if (resp.status >= 400) return Promise.reject(resp);
    return await resp.json();

}


